using Luban.CodeTarget;
using Luban.Defs;
using Scriban;

namespace Luban.Lua.CodeTarget;

[CodeTarget("lua-lua")]
public class LuaLuaCodeTarget : LuaCodeTargetBase
{

}
