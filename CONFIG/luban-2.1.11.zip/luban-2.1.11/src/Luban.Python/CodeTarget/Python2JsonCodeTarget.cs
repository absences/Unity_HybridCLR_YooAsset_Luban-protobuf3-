using Luban.CodeTarget;
using Luban.Defs;
using Scriban;

namespace Luban.Python.CodeTarget;

[CodeTarget("python-json")]
public class Python2JsonCodeTarget : PythonCodeTargetBase
{

}
