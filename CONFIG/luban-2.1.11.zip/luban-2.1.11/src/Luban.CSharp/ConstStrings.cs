namespace Luban.CSharp;

public static class ConstStrings
{
    public const string ListTypeName = "System.Collections.Generic.List";
    public const string HashSetTypeName = "System.Collections.Generic.HashSet";
    public const string HashMapTypeName = "System.Collections.Generic.Dictionary";
}
