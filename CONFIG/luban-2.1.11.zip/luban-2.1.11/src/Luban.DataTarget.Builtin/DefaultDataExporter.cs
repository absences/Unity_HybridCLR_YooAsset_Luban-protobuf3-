﻿using Luban.DataTarget;

namespace Luban.DataExporter.Builtin;

[DataExporter("default")]
public class DefaultDataExporter : DataExporterBase
{

}
