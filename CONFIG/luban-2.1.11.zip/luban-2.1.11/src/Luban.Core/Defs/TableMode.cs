namespace Luban.Defs;

public enum TableMode
{
    ONE,
    MAP,
    LIST,
}
