namespace Luban.Serialization;

public enum EDeserializeError
{
    OK,
    NOT_ENOUGH,
    EXCEED_SIZE,
    // UNMARSHAL_ERR,
}
