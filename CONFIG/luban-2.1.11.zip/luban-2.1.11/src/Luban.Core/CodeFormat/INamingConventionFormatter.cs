namespace Luban.CodeFormat;

public interface INamingConventionFormatter
{
    string FormatName(string name);
}
