namespace Luban;

[AttributeUsage(AttributeTargets.Assembly)]
public class RegisterBehaviourAttribute : Attribute
{

}
