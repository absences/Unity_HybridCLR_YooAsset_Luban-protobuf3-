namespace Luban;

// public interface IGenerationContext
// {
//     public static IGenerationContext Ins { get; set; }
//     
//     bool NeedExport(List<string> groups);
//     
//     string TopModule { get; }
//
//     public GenerationArguments Arguments { get; }
// }
